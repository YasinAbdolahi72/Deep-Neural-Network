import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.rc('font', family='Times New Roman', size=10)
np.random.seed(42)
# Data
x = np.array([-1, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1,
              0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1])
y = np.array([-0.96, -0.577, -0.073, 0.377, 0.641, 0.66, 0.461, 0.134,
              -0.201, -0.434, -0.5, -0.393, -0.165, 0.099, 0.307, 0.396,
              0.345, 0.182, -0.031, -0.219, -0.321])

# Hyperparameters
activation_functions = ['tanh', 'sigmoid', 'radialbasis', 'relu']
n = 1  # input features
n1 = 40  # hidden layer 1
n2 = 40  # hidden layer 2
m = 1  # output

# Activation functions
def activation(z, act_type, der=False):
    if act_type == 'tanh':
        if der:
            return 1 - np.tanh(z) ** 2
        return np.tanh(z)

    elif act_type == 'sigmoid':
        if der:
            sig = 1 / (1 + np.exp(-z))
            return sig * (1 - sig)
        return 1 / (1 + np.exp(-z))

    elif act_type == 'radialbasis':
        if der:
            return -1 * z * np.exp(-(z ** 2)/2)
        return np.exp(-(z ** 2)/2)

    elif act_type == 'relu':  # ReLU
        if der:
            return np.where(z > 0, 1, 0)
        return np.maximum(0, z)


# Function to train neural network
def train_neural_network(epochs, activation_type):
    alpha = 0.03
    momentum = 0.7
    v1 = 0
    v2 = 0
    v3 = 0

    W1 = 2*np.random.randn(n1, n + 1)
    W2 = 3*np.random.randn(n2, n1 + 1)
    W3 = 4*np.random.randn(m, n2 + 1)

    if activation_type == 'sigmoid':
        W1 = 3*np.random.randn(n1, n + 1)
        W2 = 3*np.random.randn(n2, n1 + 1)
        W3 = 3*np.random.randn(m, n2 + 1)
        alpha = 0.01

    if activation_type == 'tanh':
        W1 = .4*np.random.randn(n1, n + 1)
        W2 = .4*np.random.randn(n2, n1 + 1)
        W3 = .4*np.random.randn(m, n2 + 1)
        alpha = 0.01

    if activation_type == 'relu':
        gain = .9
        W1 = gain * np.random.randn(n1, n + 1)
        W2 = gain * np.random.randn(n2, n1 + 1)
        W3 = gain * np.random.randn(m, n2 + 1)
        alpha = 0.01
        momentum = 0.9

    losses = []

    # Training loop
    for epoch in range(epochs):
        total_loss = 0
        for i in range(len(x)):
            # i = np.random.randint(0, len(x))

            # Forward pass with normalized data
            data = np.array([x[i], 1])  # normalized input + bias
            z1 = W1 @ data
            a1 = activation(z1, activation_type)
            A1 = np.concatenate((a1, [1]))  # add bias

            z2 = W2 @ A1
            a2 = activation(z2, activation_type)
            A2 = np.concatenate((a2, [1]))  # add bias

            z3 = W3 @ A2
            a3 = z3  # linear output

            # Loss (squared error) with normalized target
            loss = 0.5 * (a3 - y[i]) ** 2
            total_loss += loss

            # Backpropagation with normalized target
            delta3 = (a3 - y[i])
            Gr_W3 = delta3.reshape(-1, 1) @ A2.reshape(1, -1)

            delta2 = (W3[:, :-1].T @ delta3) * activation(z2, activation_type, der=True)
            Gr_W2 = delta2.reshape(-1, 1) @ A1.reshape(1, -1)

            delta1 = (W2[:, :-1].T @ delta2) * activation(z1, activation_type, der=True)
            Gr_W1 = delta1.reshape(-1, 1) @ data.reshape(1, -1)

            v1 = momentum * v1 + (1 - momentum) * Gr_W1
            v2 = momentum * v2 + (1 - momentum) * Gr_W2
            v3 = momentum * v3 + (1 - momentum) * Gr_W3

            W1 -= alpha * v1
            W2 -= alpha * v2
            W3 -= alpha * v3

        losses.append(total_loss / len(x))

    predictions = []
    for i in range(len(x)):
        data = np.array([x[i], 1])
        z1 = W1 @ data
        a1 = activation(z1, activation_type)
        A1 = np.concatenate((a1, [1]))
        z2 = W2 @ A1
        a2 = activation(z2, activation_type)
        A2 = np.concatenate((a2, [1]))
        z3 = W3 @ A2
        a3 = z3

        prediction_denorm = a3.item()
        predictions.append(prediction_denorm)

    return predictions, losses


# Test all combinations
print("Testing Neural Networks with Different Activation Functions and Epochs...")
print("=" * 70)

idx = 0
epochs = 1000
fig, axes = plt.subplots(2, 2, figsize=(5, 4.5))
axes = axes.flatten()
for activation_type in activation_functions:

    predictions, losses = train_neural_network(epochs, activation_type)
    axes[idx].plot(x, y, 'o-', label='True Values', linewidth=1, markersize=4, color='blue')
    axes[idx].plot(x, predictions, 's-', label='Predictions', linewidth=1, markersize=4, color='red')
    axes[idx].set_xlabel('Input (x)')
    axes[idx].set_ylabel('Output (y)')
    axes[idx].set_title(f'{activation_type.upper()}')
    axes[idx].legend(loc='lower right')
    axes[idx].set_ylim([-1.5, 1])
    axes[idx].grid(True, alpha=0.3)
    idx += 1
plt.subplots_adjust(hspace=.55, wspace=0.55)
plt.savefig('FigB2-1.svg', format='svg')
plt.show()

plt.figure(figsize=(5, 3))
axes = axes.flatten()
for activation_type in activation_functions:

    predictions, losses = train_neural_network(epochs, activation_type)
    plt.plot(losses, label=f'{activation_type}')

plt.yscale("log")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend(loc='upper right')
plt.grid(True)
plt.tight_layout()
plt.savefig('FigB2-1.svg', format='svg')
plt.legend()
plt.show()

print("\n" + "=" * 70)
print("Analysis Complete!")
print("All plots have been saved as PNG files.")
print("=" * 70)
