import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rc('font', family='Times New Roman', size=10)

np.random.seed(42)

# Define the input matrix X (2x10)
X = np.array([
    [0.1, 0.7, 0.8, 0.8, 1.0, 0.3, 0.0, -0.3, -0.5, -1.5],
    [1.2, 1.8, 1.6, 0.6, 0.8, 0.5, 0.2, 0.8, -1.5, -1.3]
])

# Define the target matrix Y (2x10)
Y = np.array([
    [1, 1, 1, 0, 0, 1, 1, 1, 0, 0],  # First output
    [0, 0, 0, 0, 0, 1, 1, 1, 1, 1]   # Second output
])

# Network parameters
n = 2  # input features
m = 2  # output features
activation_functions = ['tanh', 'sigmoid', 'radialbasis', 'relu']
# Sigmoid activation function
def activation(z, act_type, der=False):
    if act_type == 'tanh':
        if der:
            return 1 - np.tanh(z) ** 2
        return np.tanh(z)

    elif act_type == 'sigmoid':
        if der:
            sig = 1 / (1 + np.exp(-z))
            return sig * (1 - sig)
        return 1 / (1 + np.exp(-z))

    elif act_type == 'radialbasis':
        if der:
            return -1 * z * np.exp(-(z ** 2)/2)
        return np.exp(-(z ** 2)/2)

    elif act_type == 'relu':  # ReLU
        if der:
            return np.where(z > 0, 1, 0)
        return np.maximum(0, z)

# Function to train neural network

def train_neural_network(epochs, act_type):
    # Initialize parameters based on activation function
    if act_type == 'relu':
        learning_rate = 0.1
        momentum = 0.9
        W = 0.1 * np.random.randn(m, n + 1) +0.15
    elif act_type == 'tanh':
        learning_rate = 0.1
        momentum = 0.9
        W = 0.1 * np.random.randn(m, n + 1)

    elif act_type == 'radialbasis':
        learning_rate = 0.1
        momentum = 0.8
        W = 0.5 * np.random.randn(m, n + 1)
    else:  # Default parameters for sigmoid
        learning_rate = 0.1
        momentum = 0.9
        W = 0.1 * np.random.randn(m, n + 1)


    # Initialize momentum
    v = np.zeros_like(W)

    losses = []

    for epoch in range(epochs):
        total_loss = 0

        for i in range(X.shape[1]):
            # Forward pass
            data = np.concatenate((X[:, i], [1]), axis=0)  # Add bias
            z = W @ data
            output = activation(z, act_type)

            # Calculate loss
            loss = 0.5 * np.sum((output - Y[:, i]) ** 2)
            total_loss += loss

            # Backward pass
            delta = (output - Y[:, i]) * activation(z, act_type, der=True)
            gradient = delta.reshape(-1, 1) @ data.reshape(1, -1)

            # Update weights with momentum
            v = momentum * v + (1 - momentum) * gradient
            W -= learning_rate * v

            if act_type == 'relu':
                learning_rate *= 0.999
                momentum *= 0.9999


        losses.append(total_loss / X.shape[1])

    return W, losses

epochs = 1000
plt.figure(figsize=(5, 3))
for activation_type in activation_functions:
    W, losses = train_neural_network(epochs, activation_type)
    plt.plot(losses, label=f'{activation_type}')

plt.xlabel("Epochs")
plt.yscale("log")
plt.ylabel("Loss")
plt.legend(loc='upper right')
plt.grid(True)
plt.tight_layout()
plt.savefig('FigB1-1.svg', format='svg')
plt.legend()
plt.show()


# Plot all X data points
x1g1 = X[0, 0:3]
x2g1 = X[1, 0:3]
x1g2 = X[0, 3:5]
x2g2 = X[1, 3:5]
x1g3 = X[0, 5:8]
x2g3 = X[1, 5:8]
x1g4 = X[0, 8:]
x2g4 = X[1, 8:]

idx = 0

fig, axes = plt.subplots(2, 2, figsize=(5, 4.5))
axes = axes.flatten()
for activation_type in activation_functions:

    W, losses = train_neural_network(epochs, activation_type)
    axes[idx].scatter(x1g1, x2g1, c='blue', marker='o', s=40, label='Group 1')
    axes[idx].scatter(x1g2, x2g2, c='red', marker='o', s=40, label='Group 2')
    axes[idx].scatter(x1g3, x2g3, c='green', marker='o', s=40, label='Group 3')
    axes[idx].scatter(x1g4, x2g4, c='black', marker='o', s=40, label='Group 4')

    out = 0  #sigmoid^-1 (0.5)

    if activation_type == 'relu':
        out = 0.5  #relu^-1 (0.5)
    if activation_type == 'tanh':
        out = 0.55  #tanh^-1 (0.5)
    if activation_type == 'radialbasis':
        out = 1.178  # #radialbasis^-1 (0.5)

    if abs(W[0, 2]) > 1e-10:  # Avoid division by zero
        x1_line = np.linspace(-2, 2, 100)
        x2_line1 = out/W[0, 1] - W[0, 2]/W[0, 1] - (W[0, 0]/W[0, 1]) * x1_line
        axes[idx].plot(x1_line, x2_line1, color=[0.5, .1, .1])

    if abs(W[1, 2]) > 1e-10:  # Avoid division by zero
        x1_line = np.linspace(-2, 2, 100)
        x2_line2 = out/W[0, 1] - W[1, 2]/W[1, 1] - (W[1, 0]/W[1, 1]) * x1_line
        axes[idx].plot(x1_line, x2_line2, color=[0.5, .1, .1])

    axes[idx].set_xlabel('X1')
    axes[idx].set_ylabel('X2')
    axes[idx].set_title(f'{activation_type.upper()}')
    axes[idx].set_ylim([-2, 2])
    axes[idx].set_xlim([-2, 2])
    axes[idx].grid(True, alpha=0.3)
    idx += 1
plt.subplots_adjust(hspace=.55, wspace=0.55)
plt.savefig('FigB1-2.svg', format='svg')
plt.show()
# #
#
#
